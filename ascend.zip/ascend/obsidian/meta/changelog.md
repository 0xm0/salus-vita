---
tags: [meta, changelog]
updated: 2026-09-30
---

# Changelog

Chronological log of notable changes to **this project**. Newest first.
Human-curated — not a mirror of `git log`.

Log a change here when it would surprise someone returning in six months: a new
dependency, a new route or section, a convention bent, a bug whose cause is worth
remembering. Routine commits do not need an entry.

For *why* the conventions are what they are, see [[decisions-log]].

---

## 2026-10-06 — owner review (D-033): brand kit + full meta (optimize/pass-2)

The owner: "generate favicon and opengraph and all required meta". Nothing else
on the site changed.

- **Mark** `src/assets/brand/mark.svg`: the wordmark's own "▲", drawn as a
  rounded triangle in the primary mint gradient (`#5df0a8 → #2fd38a`) on the
  deep-space ground `#04060f`. Reads at 16 px.
- **`optimization-pipeline/tools/scaffold-brand.mjs`**: `public/icon.svg`,
  `favicon.ico` (16/32/48; the starter's `src/app/favicon.ico` deleted so
  `icon.svg` leads), 16/32 PNGs, apple 180, android 36–192, `icon-512`,
  `icon-maskable-512`, `manifest.json` ("Ascend", `#04060f`, the hero sub as
  description), `open-graph.jpg` (1200×630 capture of the hero: headline,
  CTAs, planet, logo row). `public/open-graph.png` (starter card) removed.
- **Meta** (`lib/site.ts`, `utils/seo/*`, `views/home.tsx`): title "Ascend —
  One platform for your entire revenue engine" (the home view now reads
  `siteConfig.title`); description = the hero sub-line; author/creator/publisher
  Ascend (was the starter's "New Project"); `twitterHandle` unset (was
  `@newproject`); `applicationName`, 6 keywords, OG 1200×630 + alt, Twitter
  image alt, `icon.svg` first; JSON-LD Organization logo → `/icon-512.png`.
  `frontend/seo-metadata.md` + `architecture/folder-structure.md` updated.
- Checks: tsc, lint, build clean; verify.sh 0 FAIL; Lighthouse local ×1 mobile
  96/100/100/100, desktop 100/100/100/100. The bot UA gets the same head.

## 2026-10-03 — round 2: idle hydration, reveal layers, owner question #34

- **Below-the-fold sections hydrate when idle** (`components/common/hydrate-when-idle.tsx`):
  features, solutions and cta. A/B back to back: mobile 95 (91/95/95) → 96 (all 96), TBT 154 → 111 ms.
- **#34 — the glass is not the cost.** (a) not applicable: the planet is one fixed full-viewport
  canvas redrawn every frame (stars, motes), so there is no static region behind any card.
  (b) blur 14 → 8 px on touch: mobile cold 1.4 → 2.75 % dropped — no help, reverted.
  Diagnostics: every backdrop blur removed → desktop cold still 2.8 %; reveals at rest → **0 %**.
  The cold drops were each block's layer being created and rastered in the first frame of its
  reveal. So (c) was not tried.
- **Fix: `Reveal` promotes its block (`will-change: opacity, transform`) from load until it
  settles**, then releases it. Desktop cold 3.3 % → **0 %** (ideal ×3), mobile 1.4 % → 0.9 %
  (**ideal**). Lighthouse desktop 100, mobile 95 (96/95/92). Glass, blur and reveals unchanged
  (QA vs live: only the planet's phase differs).

## 2026-10-03 — D-028 pass (mobile 90): planet after the headline, sized textures, warm-up

Local Lighthouse, back to back on a shared machine. Baseline (local): desktop 80 (68/85/80),
mobile 51 (51/49/54), LCP 5.6 s — the headline waited behind three.js, Draco, the cloud PNG and
the night-lights model, all fetched and parsed before its first frame.

- **Planet starts after the headline paints** (`planet-canvas.tsx`): an LCP entry on the `<h1>`,
  or 1.5 s. Measured alone (without it, everything else in): mobile 73, LCP 6.9 s → with it 92, LCP 2.7 s.
- **Model builds at the size the GPU used**: three resampled the 6000² maps to 4096² (and the 4000²
  night map to 2048²) on the main thread at load. `planet-4096.glb` (desktop), `planet-2048.glb`
  (phones, < 768 px), `planet-lights-2048.glb`: `npx @gltf-transform/cli@4 resize --width N --height N`
  then `draco`. Clouds `planet-clouds.webp` (`cwebp -q 90 -alpha_q 100`, 620 → 236 KB). Both models
  fetched in parallel. Old files deleted. Screens vs live: same globe (city lights, terrain).
- With the two above: desktop 80 → 95, mobile 51 → 87.
- **Warm-up one step per task** (`planet.ts`): each texture upload (`initTexture`), the clouds',
  halo's and globe's compile (shown for the `compile` call only), then markers a task later; setup
  in its own task after three's evaluation; first frame on rAF. Desktop 95 → 100 (2/3), mobile 87 → 92
  (94/91/92), TBT 393 → 219 ms.
- `src/app/loading.tsx` deleted; `prefetch={false}` on the banner's privacy link.
- Closing (5 runs, load ~14): desktop **98** (96–100), mobile **90** (81/93/80/91/90), LCP 2.65 s.
  Robot 100/100. Scroll: cold smooth (~2 % dropped, the glass cards' first reveal), warm ideal,
  on both — as before (open question #34).

## 2026-10-01 — Ascend rebuilt on the starter

- The shipped Vite page (ascend-old/src) ported: the same four sections, copy,
  palette, scale and fixed WebGL planet. Content in `src/data/mocks/home.ts`,
  view in `src/views/home.tsx`, the scene in `src/lib/scene/planet.ts` (loaded
  lazily by `components/scene/planet-canvas.tsx`), reveals as springs
  (`components/ui/reveal.tsx`, the old observer's threshold 0.18 / −8 %).
- Dependencies: `three@0.143.0`, `@types/three@0.143.0` (ADR-0026). Inter
  400–900 via next/font replaces Onest (the old page loaded Inter).
- The adaptive rem grid off (ADR-0027); `body` line-height `normal`.
- The old `dist/` was a build from before the source's last edits (headline,
  hero lift) — the source is the spec.

## Baseline — built from `next16-claude-starter` v0.1.0

What the starter ships, so the first project entry has something to diff against:

| Area | What is there |
|------|---------------|
| Framework | Next.js 16 App Router · React 19 · TypeScript · Yarn · Node ≥ 20.19 |
| Styling | Tailwind v4, CSS-only config, three-tier design tokens ([[design-system]]) |
| Motion | Vendored spring engine + `spring-text-engine`, shared rAF ticker, reduced-motion ([[animation-system]]) |
| Layout | Adaptive scaling grid — root font-size tracks the viewport ([[design-system]]) |
| Scroll | Lenis smooth scroll + Zustand scroll store ([[smooth-scroll]]) |
| Server | `app/api` route handlers, zod-validated env, `{ data }`/`{ error }` envelope ([[api-architecture]]) |
| SEO | Metadata generator, `robots.ts`, `sitemap.ts`, JSON-LD ([[seo-metadata]]) |
| Agent harness | 8 commands, 7 path-scoped rules, 11 skills, 4 subagents, `verify.sh` ([[agent-harness]]) |
| Not included | CMS, database, auth, payments, i18n, tests — added per project ([[backend/README]]) |

The home view (`src/views/home.tsx`, route `/`) ships empty on purpose — start
there ([[new-page]]).

<!-- Log this project's changes below, newest first, under a `## YYYY-MM-DD` heading. -->

## 2026-09-30 — Dependency refresh: Next 16.3.7, React 19.3

Bumped to pick up upstream Turbopack fixes in the 16.3.x patch line.

- `next` + `eslint-config-next` 16.3.1 → 16.3.7
- `react` / `react-dom` 19.2.8 → 19.3.0 (and `@types/react*` → 19.3.0)
- `zod` 4.4.3 → 4.6.5 · `@types/node` → 24.19.0
- Still held back (see [[tech-stack]] § Deliberately held back): ESLint 10,
  TypeScript 7, `@types/node` 26.
- Installs must run on the `.nvmrc` Node (24.16.0); Yarn rejects Node < 20.19
  via `engines`.

## 2026-09-18 — `optimize-load`: Lighthouse as a measured workflow

- **New skill `optimize-load`** + `/load` command + [[optimize-load]]. Audits all
  four Lighthouse categories across **laptop, tablet and mobile**, medians of 3+
  runs, then fixes what the audit blames and re-measures. Hard rule 13 now routes
  by *which half* is slow — load → `optimize-load`, scroll jank after load →
  `optimize-performance` — because Lighthouse never scrolls and cannot see the
  second.
- **`references/runner.md`** carries the Lighthouse Node-API runner (three form
  factors, medians, per-audit failures by weight), a `PerformanceObserver` CLS
  probe — Lighthouse routinely reports shifts with **no node attached** — and the
  WCAG contrast arithmetic.
- **`references/fixes.md`** carries the fixes by weight (TBT 30 · LCP 25 · CLS 25),
  the LCP phase-breakdown table that names which fix applies, the measured
  contrast floors (**0.55 black on light, 0.46 white on black**), and the
  width-reservation pattern for figures that count up.
- **Findings worth carrying between projects**, all recorded: a single run is an
  anecdote (LCP swung 2.7→4.6s on an unchanged build); axe samples animated pages
  mid-reveal and reports artifacts; CLS sums distance, not frames, so speeding an
  animation up does nothing; and a CLS of 0 may just mean the trace ended early.
- **Ownership tidied so the skills cannot drift** — `seo-audit` §5 and
  [[seo-aeo]] now delegate Core Web Vitals to `optimize-load` instead of
  restating them (they were still advising a single Lighthouse run on one
  profile).
- **The ship gate now routes through it** — [[ship]] and the `ship-check` skill
  ask for all four categories ≥ 90 on all three profiles, medians of 3+, and name
  `optimize-performance` as the second pass Lighthouse cannot do.
- **No new dependency** — both scripts install into a scratch directory.
- See [[decisions-log]] ADR-0025 for why this is a second skill rather than an
  extension of the first.


## 2026-09-17 — performance becomes a measured workflow

- **New skill `optimize-performance`** + `/perf` command + [[optimize-performance]].
  Performance work now runs a loop — build, measure in real Chrome, attribute,
  fix one thing, re-measure — instead of applying a checklist. Hard rule 13 in
  `AGENTS.md` routes any "it's slow / janky / stutters" request into it; the old
  3D rule moved to 14.
- **The diagnostic it adds:** scroll the whole page twice and compare cold
  against warm. A page that stutters on the *first* pass and is smooth after is
  not slow — it is fetching and decoding lazy media inside the frames a reveal
  animation is running in. Lighthouse cannot see this (it never scrolls), and
  neither can you by hand, because you have already warmed the page.
- **References:** `references/measuring.md` carries the scroll bench (real wheel
  events over CDP, `requestAnimationFrame` deltas, long tasks, resource timing)
  and how to read it; `references/fixes.md` carries the fixes, most-likely first,
  including a `warmMedia` implementation with the four traps that make a naive
  version silently do nothing.
- **No new dependency** — the bench uses `playwright-core` installed in a scratch
  directory, not in the project.
- See [[decisions-log]] ADR-0024 for why this is a loop rather than a checklist.


## 2026-09-08

**`optimize-3d-scene` skill — resize no longer switched off on touch.** §13 of
the skill (and `patterns.md` §5 / §14) told agents to attach *no* `resize`
listener on the mobile tier, to dodge the iOS URL bar. That also removed the
only path that could react to a breakpoint drag, a rotation or DevTools
emulation being turned off, so a scene loaded as a phone kept its phone
framebuffer, frame budget, parked pointer and hidden desktop passes on a desktop
viewport and rendered skewed. The skill now listens on every tier, ignores
height-only changes on a coarse pointer, and re-reads the tier on a width
change or a pointer-media-query flip, with a `retune()` that re-applies DPR,
budget, visibility, draw range and pointer binding without compiling a program.
§2 and §11 of `SKILL.md` and the [[optimize-3d-scene]] workflow note were
updated to match; §14 gained a tier-switch round-trip check. Reasoning in
[[decisions-log]] ADR-0023. Measured on the project that surfaced it: phone
390×844 / 3 draws ↔ desktop 2160×1350 / 4 draws, program count unchanged.
