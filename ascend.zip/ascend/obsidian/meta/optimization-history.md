---
tags: [meta, optimization]
updated: 2026-10-06
---

# Optimization history — Ascend

What the performance/SEO optimization pipeline changed in this project, why,
and what must not be undone. Maintained by the optimization pipeline
(`getlayers-pipeline/optimization-pipeline`); the full chronological record with
every measurement is its `obsidian/Projects/ascend.md`, raw runs in
`runs/ascend/`. Per-change prose is in [[changelog]] (entries from 2026-10-01
"Ascend rebuilt on the starter" to 2026-10-06 "owner review (D-033)"); ADR-0026
(three@0.143 pinned) and ADR-0027 (fixed 16 px root) are in [[decisions-log]].
D-numbers are the pipeline's decisions log. Last updated 2026-10-06.

## Current state

- **Live:** https://getlayers-ascend-uyidhjabskjhdbfjn.vercel.app (repo
  `textura-agency/getlayers-ascend`, deploys `main`). This is a **rebuild**
  (2026-10-01) of the old Vite + three@0.143 site (`ascend-old/`) on the starter
  (D-021/D-022). Status: **optimized** (2026-10-03, D-028).
- **Lighthouse, production** (D-029 sweep, 2026-10-04, 3 runs): people desktop
  99 / mobile 98, A11y/BP/SEO 100; robot form 100 across on both devices.
  After D-033 (local ×1): mobile 96, desktop 100, 100s.
- **Scroll, production** (D-031 sweep, 2026-10-06, 3 runs): desktop **ideal**
  (0 %, max 10.4 ms), mobile **smooth** (1.06 %, max 51.1 ms) — the quiet
  re-check on 2026-10-03 read mobile ideal (0.95 %).
- Last commit on `main`: `5ebdd49` (D-033 brand kit + meta).

## Invariants — do not undo

- **The planet starts only after the hero headline has painted** —
  `src/components/scene/planet-canvas.tsx` waits for a
  `largest-contentful-paint` entry on the `<h1>` (with a timeout fallback). The
  `<h1>` fade is the phone LCP; three.js, Draco, the cloud PNG and the lights
  model all parsed before its first frame. Alone: mobile 73 → 92, LCP 6.9 →
  2.7 s.
- **Models ship at the GPU's real texture size** — `public/assets/planet-4096.glb`
  (desktop), `planet-2048.glb` (phones), `planet-lights-2048.glb`; clouds
  `planet-clouds.webp` (620 → 236 KB); fetched in parallel. three.js resampled
  the 6000² / 4000² maps to 4096 / 2048 on the main thread at runtime.
- **Warm-up in tasks** — one texture upload / program compile / marker per task,
  each object visible only during its own compile (`src/lib/scene/planet.ts`).
  PC 95 → 100, mobile 87 → 92, TBT 393 → 219 ms.
- **Tiered DPR: desktop ≤ 1.5, phone 1.0** (`tierDpr` in `planet.ts`; renderer,
  composers and point-size uniforms) — the planet ran at full device DPR through
  three composers: PC 14 % → 8 % dropped.
- **The TORUS and BLOOM composers are gone** — nothing lives on their layers;
  they bloomed a black frame every frame. The final pass samples a 1×1 black
  texture in their place — same image. PC 8 % → 5 %.
- **Reveal blocks carry `will-change: opacity, transform` from load until the
  reveal settles** — `src/components/ui/reveal.tsx`. The scroll cost was each
  block's layer promotion + raster on its reveal's first frame, **not the glass
  blur** (#34 answered). Desktop cold 3.3 → 0 % (ideal), mobile 1.4 → 0.9 %.
- **`Reveal` latches the in-view state** (`seen`, `reveal.tsx`) — the engine's
  `Spring` checks `enabled` before `once`, so `enabled={inView}` hid and
  replayed on return; the shipped page played each once (`a053255`).
- **Features / solutions / CTA hydrate one per idle moment** —
  `src/components/common/hydrate-when-idle.tsx`. Mobile 95 → 96, TBT 154 →
  111 ms.
- **Robot form (D-016)** — `src/proxy.ts`; the planet is a still
  (`public/assets/robot/planet-{desktop,mobile}.webp`), reveals at rest via
  `robot-spring`. Same content.
- **Brand kit + meta (D-033)** — `src/assets/brand/mark.svg` (the "▲" in the
  mint gradient on `#04060f`), favicon set, OG 1200×630; title "Ascend — One
  platform for your entire revenue engine"; author Ascend (was "New Project"),
  `@newproject` dropped. Bot UA head = people head.
- **Rebuild fidelity rules** — three@0.143.0 pinned (ADR-0026), fixed 16 px root
  (ADR-0027), `public/draco/` decoder; copy verbatim from the old source
  (`ascend-old/dist/` was stale).
- **Bot list includes AI crawlers** (`src/utils/bot-ua.ts`, `a137dc0`); consent
  banner SSR (`src/components/common/Cookie/consent-flag.ts`) — it was the
  mobile LCP at baseline; `/privacy-policy` (BP 96 → 100); D-019 origin; **no
  `src/app/loading.tsx`**; `prefetch={false}` on non-navigating links.

## Owner decisions that bind this project

- D-016 / D-017 (2026-09-29) — robot form; A11y/BP/SEO 100.
- D-021 / D-022 (2026-09-30) — the non-Next site gets a clean starter repo and
  a 1:1 rebuild before pass 1.
- D-023 / D-024 (2026-10-01) — rebuild accepted on 1:1 visuals and motion;
  native cursor never hidden; designed on every device; zero console errors.
- D-026 (2026-10-01) — keep it beautiful; no mobile 3D cut without asking.
- D-027 (2026-10-01) — all pass branches merged (ascend as a merge commit
  `f4e1197`: main had the rebuild's latch fix).
- D-028 / D-029 (2026-10-02/03) — mobile ≥ 90, 100 elsewhere, production (met).
- D-031 (2026-10-05) — scroll ideal (desktop ideal; mobile smooth on the last
  sweep).
- **D-033 (2026-10-06)** — favicon + OpenGraph + all required meta (done);
  `optimize/pass-2`, merged by D-034.

## History by pass

**Rebuild — 2026-10-01, commit `1231399`.** `planet.js` ported to TS line for
line; `compare-rebuild` identical boxes at 1440/1024/390.

**Pass 1 — 2026-09-30/10-01, commit `c82cd88`.** Baseline (hosted, live):
PC 99 / mobile 77, BP 96, robot 98/76; scroll janky both (PC 14 % dropped,
steady ~30 fps). Tiered DPR; dead composers removed; robot form, banner SSR,
privacy, origin. Hosted after: PC 98 / mobile 74 (TBT ~1 s), robot 100 across;
scroll PC janky 5–6 %, mobile smooth. `blocked` on #34 (glass blur; hero
fade-in LCP).
- Follow-up `a053255`/`58ae1c3`: reveals play once.
- `a137dc0` (2026-10-02): AI crawlers.

**D-028 — 2026-10-03, commit `b1ed08d`.** Round 1: planet after the headline,
sized textures, task warm-up, `loading.tsx` deleted → local PC 98 / mobile 90.
Round 2: idle hydration, reveal `will-change` → mobile 95–96, desktop scroll 0 %.
Hosted after (5 runs, load ~17): PC 100 / mobile 97 (was 98 / 74), robot
100/99; quiet production re-check: scroll ideal both. **Optimized.**

**D-029 production sweep — 2026-10-04:** 99 / 98, robot 100/100.
**D-031 production scroll sweep — 2026-10-06:** desktop ideal, mobile smooth
(1.06 %).
**D-033 — 2026-10-06, commit `5ebdd49`:** brand kit + full meta.

## Tried and reverted / didn't help

- Scene init on `requestIdleCallback`: mobile 73 (68–76), no change — Lantern
  still counts the three chunk's 450 ms parse/init. Reverted.
- Glass blur 14 → 8 px on touch: no better, reverted. Removing every backdrop
  blur: desktop still 2.8 % — the glass was never the cost.
- A hosted scroll "smooth" at machine load ~17 (one 416 ms frame at #solutions)
  was the machine; the quiet re-check read ideal.

## Open items / leads

- **Mobile scroll smooth on the 2026-10-06 sweep** (1.06 %, max 51.1 ms); an
  earlier quiet check had one 52 ms render frame 1/3 at #cta.
- Fleet phone-frame-cap candidate (pattern match, untriaged) — this project
  was approved in D-033 except for the meta; ask before touching (#50).
- Mobile perf margin was thin in local runs (81/93/80/91/90) before round 2.

## How to measure

Run from `getlayers-pipeline/optimization-pipeline`:

```sh
node tools/measure.mjs ascend --hosted --runs 5   # Lighthouse + scroll, PC + mobile
node tools/measure.mjs ascend --hosted --as-bot   # robot form
node tools/fps-probe.mjs <url>                    # planet fps
node tools/compare-motion.mjs <oldUrl> <newUrl> --out <dir>   # motion vs ascend-old (D-023)
node tools/qa-shots.mjs ascend --against-live 'hero=/'   # the planet rotates: diffs of a few % are motion
```

Scroll records at machine load > ~15 are not trustworthy here — re-check in a
quiet window.
