// 📖 Docs: obsidian/frontend/views.md

import type { Metadata } from "next";

import { HydrateWhenIdle } from "@/components/common/hydrate-when-idle";
import { Icon } from "@/components/ui/icons";
import { ascendContent as c } from "@/data/mocks/home";
import { siteConfig } from "@/lib/site";
import { generateMetadata } from "@/utils/seo/generate-page-metadata";
import { PlanetCanvas } from "@/components/scene/planet-canvas";
import { Reveal } from "@/components/ui/reveal";
import { RobotProvider, RobotView } from "@/components/common/robot-view";

/** The home route's metadata — the shipped page's own title (ascend-old/index.html). */
export const homeMetadata: Metadata = generateMetadata({
  title: siteConfig.title,
  url: "/",
});

const BTN =
  "inline-flex items-center gap-[9px] whitespace-nowrap rounded-full border border-transparent px-[22px] py-[13px] text-a15 font-semibold transition-[transform,box-shadow,background-color,border-color] duration-[var(--duration-normal)] ease-entrance [&_svg]:size-[17px]";
const BTN_PRIMARY = `${BTN} bg-primary-gradient text-accent-ink shadow-primary hover:-translate-y-0.5 hover:shadow-primary-hover`;
const BTN_OUTLINE = `${BTN} border-line-strong bg-tint-4 text-ink backdrop-blur-[10px] hover:-translate-y-0.5 hover:bg-tint-9`;
const EYEBROW = "mb-[18px] inline-block text-a12 font-semibold uppercase tracking-[0.18em] text-accent";
const H2 = "text-section font-extrabold leading-[1.05] tracking-[-0.02em] text-shadow-heading";
const SECTION = "relative z-[1] mx-auto max-w-content px-6 py-section max-[720px]:px-5 max-[720px]:py-section-sm";

const Brand = () => (
  <a href="#top" className="inline-flex items-center gap-[9px] text-a19 font-extrabold tracking-[0.16em]">
    <span aria-hidden="true" className="-translate-y-px text-a14 text-accent">▲</span> {c.brand}
  </a>
);

/**
 * Ascend — the shipped landing page (ascend-old/src/App.jsx) rebuilt on the
 * starter: the same sections, copy, palette and scale over the same fixed
 * WebGL planet. A Server Component; the planet and the reveals are client
 * leaves (hard rule #6), the reveals are springs (hard rule #1).
 */
export const HomeView = ({ robot = false }: { robot?: boolean }) => (
  // A robot gets the page at rest (D-016): the planet as a still, reveals at
  // their end state.
  <RobotProvider robot={robot}>
  {robot && <RobotView />}
  <div id="top" className="relative font-ascend">
    <PlanetCanvas />

    {/* ── SECTION 1 · HERO ── */}
    <header className="hero-scrim relative z-[1] flex min-h-screen flex-col">
      <nav aria-label="Primary" className="mx-auto flex w-full max-w-content items-center justify-between gap-6 px-6 py-[22px] max-[720px]:px-5 max-[720px]:py-[18px]">
        <Brand />
        <ul className="flex list-none gap-[30px] text-a14-5 text-muted max-[720px]:hidden">
          {c.nav.map((item) => (
            <li key={item}>
              <a href={`#${item.toLowerCase()}`} className="transition-colors duration-[var(--duration-fast)] ease-entrance hover:text-ink">
                {item}
              </a>
            </li>
          ))}
        </ul>
        {/* Its own padding, not BTN's: the shipped .btn-ghost is 9 × 18. */}
        <a href="#cta" className="inline-flex items-center whitespace-nowrap rounded-full border border-line-strong bg-tint-5 px-[18px] py-[9px] text-a15 font-semibold text-ink transition-colors duration-[var(--duration-normal)] ease-entrance hover:bg-tint-10">
          {c.navCta}
        </a>
      </nav>

      <div className="flex flex-1 -translate-y-[10vh] flex-col items-center justify-center px-6 pt-10 text-center max-[720px]:px-5 max-[720px]:pt-6">
        <Reveal delay={60}>
          <h1 className="max-w-[15ch] text-hero font-extrabold leading-[1.04] tracking-[-0.03em] text-shadow-hero">
            {c.hero.titleLead}
            <br />
            {c.hero.titleTail} <em className="text-accent-gradient not-italic">{c.hero.titleAccent}</em>
          </h1>
        </Reveal>
        <Reveal delay={180}>
          <p className="mt-6 max-w-[560px] text-lead leading-[1.6] text-muted">{c.hero.sub}</p>
        </Reveal>
        <Reveal delay={300} className="mt-[38px] flex flex-wrap justify-center gap-[14px] max-[560px]:w-full [&>a]:max-[560px]:flex-1 [&>a]:max-[560px]:justify-center">
          <a href="#cta" className={BTN_PRIMARY}>
            {c.hero.primary} <Icon name="arrow" />
          </a>
          <a href="#cta" className={BTN_OUTLINE}>{c.hero.secondary}</a>
        </Reveal>
      </div>

      <Reveal delay={420} className="mx-auto w-full max-w-content px-6 pb-logos text-center">
        <span className="mb-5 block text-a12 uppercase tracking-[0.16em] text-muted-2">{c.logos.label}</span>
        <ul className="flex list-none flex-wrap items-center justify-center gap-logos-gap max-[720px]:gap-x-[30px] max-[720px]:gap-y-[22px]">
          {c.logos.items.map((l) => (
            <li key={l} className="text-a17 font-bold tracking-[0.02em] text-muted-2 opacity-80 transition-[color,opacity] duration-[var(--duration-normal)] ease-entrance hover:text-ink hover:opacity-100">
              {l}
            </li>
          ))}
        </ul>
      </Reveal>
    </header>

    <main>
      {/* Below the fold: each section hydrates in an idle moment of its own
          after load, not in the page's one hydration commit (D-028 lever 3). */}
      {/* ── SECTION 2 · FEATURES ── */}
      <HydrateWhenIdle>
      <section id="features" aria-labelledby="features-title" className={SECTION}>
        <div className="mx-auto mb-head max-w-[680px] text-center">
          <Reveal><span className={EYEBROW}>{c.features.eyebrow}</span></Reveal>
          <Reveal delay={80}><h2 id="features-title" className={H2}>{c.features.heading}</h2></Reveal>
          <Reveal delay={160}><p className="mt-[18px] text-a18 leading-[1.65] text-muted text-shadow-body">{c.features.lead}</p></Reveal>
        </div>
        <ul className="grid list-none grid-cols-3 gap-[18px] max-[980px]:grid-cols-2 max-[560px]:grid-cols-1 max-[560px]:gap-[14px]">
          {c.features.items.map((f, i) => (
            <Reveal key={f.title} tag="li" delay={i * 90}>
              <article className="card-wash relative h-full overflow-hidden rounded-card border border-line bg-glass p-[30px] backdrop-blur-[14px] transition-[transform,border-color,background-color] duration-[var(--duration-normal)] ease-entrance hover:-translate-y-1 hover:border-line-strong hover:bg-glass-2 max-[560px]:p-6">
                <span className="mb-5 inline-flex size-[46px] items-center justify-center rounded-icon border border-accent-edge bg-accent-wash text-accent [&_svg]:size-[22px]">
                  <Icon name={f.icon} />
                </span>
                <h3 className="mb-[9px] text-a19 font-bold">{f.title}</h3>
                <p className="text-a15 leading-[1.6] text-muted">{f.body}</p>
              </article>
            </Reveal>
          ))}
        </ul>
      </section>
      </HydrateWhenIdle>

      {/* ── SECTION 3 · SHOWCASE + STATS ── */}
      <HydrateWhenIdle>
      <section id="solutions" aria-labelledby="solutions-title" className={SECTION}>
        <div className="grid grid-cols-[1fr_1.05fr] items-center gap-showcase max-[980px]:grid-cols-1 max-[980px]:gap-10">
          <div className="max-[980px]:mx-auto max-[980px]:max-w-[620px] max-[980px]:text-center">
            <Reveal><span className={EYEBROW}>{c.showcase.eyebrow}</span></Reveal>
            <Reveal delay={90}><h2 id="solutions-title" className={`${H2} mb-[18px]`}>{c.showcase.heading}</h2></Reveal>
            <Reveal delay={180}><p className="mb-[30px] text-a18 leading-[1.65] text-muted text-shadow-body">{c.showcase.lead}</p></Reveal>
            <Reveal delay={270}>
              <a href="#cta" className={BTN_PRIMARY}>
                {c.showcase.cta} <Icon name="arrow" />
              </a>
            </Reveal>
          </div>

          <Reveal delay={160}>
            <div aria-hidden="true" className="dash-edge relative rounded-card-lg border border-line-strong bg-glass-2 p-6 shadow-panel backdrop-blur-[18px]">
              <div className="mb-[22px] flex items-center justify-between">
                <span className="text-a15 font-bold">{c.showcase.dashTitle}</span>
                <span className="inline-flex items-center gap-[7px] text-a12 font-semibold text-accent">
                  <span className="size-[7px] rounded-full bg-accent shadow-dot" /> {c.showcase.dashLive}
                </span>
              </div>
              <div className="mb-[18px] flex h-bars items-end gap-[10px] rounded-bars border border-line bg-well px-1 py-[14px]">
                {c.showcase.bars.map((h, i) => (
                  <span key={i} className="bg-bar-gradient flex-1 rounded-t-[6px] rounded-b-[3px]" style={{ height: `${h}%` }} />
                ))}
              </div>
              <div className="flex flex-col gap-[13px]">
                {c.showcase.rows.map((r) => (
                  <div key={r.label} className="grid grid-cols-[120px_1fr] items-center gap-[14px] text-a13-5 text-muted max-[560px]:grid-cols-[90px_1fr]">
                    <span>{r.label}</span>
                    <span className="h-2 overflow-hidden rounded-full bg-tint-6">
                      <span className="bg-fill-gradient block h-full rounded-full" style={{ width: `${r.fill}%` }} />
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>

        <ul className="mt-stats grid list-none grid-cols-4 gap-[18px] max-[980px]:grid-cols-2 max-[560px]:gap-3 max-[380px]:grid-cols-1">
          {c.stats.map((s, i) => (
            <Reveal key={s.label} tag="li" delay={i * 80}>
              <div className="rounded-card border border-line bg-glass px-[18px] py-[30px] text-center backdrop-blur-[12px] max-[560px]:px-3 max-[560px]:py-[22px]">
                <span className="text-stat-gradient block text-stat font-extrabold tracking-[-0.02em]">{s.value}</span>
                <span className="mt-2 block text-a14 text-muted">{s.label}</span>
              </div>
            </Reveal>
          ))}
        </ul>
      </section>
      </HydrateWhenIdle>

      {/* ── SECTION 4 · CTA ── */}
      <HydrateWhenIdle>
      <section id="cta" aria-labelledby="cta-title" className={SECTION}>
        <Reveal>
          <div className="bg-cta-gradient relative mx-auto max-w-[760px] overflow-hidden rounded-card-lg border border-line-strong px-cta-x py-cta-y text-center shadow-panel backdrop-blur-[18px] max-[560px]:px-[22px] max-[560px]:py-10">
            <Reveal delay={60}><span className={EYEBROW}>{c.cta.eyebrow}</span></Reveal>
            <Reveal delay={140}><h2 id="cta-title" className={`${H2} mb-4`}>{c.cta.heading}</h2></Reveal>
            <Reveal delay={220}><p className="mx-auto mb-8 max-w-[520px] text-a18 leading-[1.6] text-muted">{c.cta.lead}</p></Reveal>
            <Reveal delay={300} className="flex flex-wrap justify-center gap-[14px] max-[560px]:w-full [&>a]:max-[560px]:flex-1 [&>a]:max-[560px]:justify-center">
              <a href="#top" className={BTN_PRIMARY}>
                {c.cta.primary} <Icon name="arrow" />
              </a>
              <a href="#top" className={BTN_OUTLINE}>{c.cta.secondary}</a>
            </Reveal>
          </div>
        </Reveal>

        {/* The footer sits inside the CTA section, sharing its padding — as the
            shipped page had it. */}
        <footer>
          <Reveal>
            <div className="mt-footer flex flex-wrap justify-between gap-12 border-t border-line pt-12 max-[720px]:gap-9 max-[560px]:flex-col">
              <div className="max-w-[280px]">
                <Brand />
                <p className="mt-[14px] text-a14-5 leading-[1.6] text-muted">{c.footer.tagline}</p>
              </div>
              <div className="flex flex-wrap gap-footer-cols max-[560px]:w-full max-[560px]:gap-8">
                {c.footer.cols.map((col) => (
                  <nav key={col.title} aria-label={col.title}>
                    <h3 className="mb-4 text-a12 font-semibold uppercase tracking-[0.14em] text-muted-2">{col.title}</h3>
                    {col.links.map((l) => (
                      <a key={l.label} href={l.href} className="mb-[10px] block text-a14-5 text-muted transition-colors duration-[var(--duration-fast)] ease-entrance hover:text-ink">
                        {l.label}
                      </a>
                    ))}
                  </nav>
                ))}
              </div>
            </div>
          </Reveal>
          <p className="mt-14 text-center text-a13 text-muted-2">
            © {new Date().getFullYear()} {c.footer.copyright}
          </p>
        </footer>
      </section>
      </HydrateWhenIdle>
    </main>

  </div>
  </RobotProvider>
);
