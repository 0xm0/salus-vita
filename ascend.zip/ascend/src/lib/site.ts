/**
 * Site-wide configuration — the single source of truth for SEO.
 *
 * Consumed by the metadata generator, `robots.ts`, `sitemap.ts`, and the
 * JSON-LD structured-data helper. Update the placeholder values per project.
 */
import { getServerEnv, publicEnv } from "@/env";

/**
 * Vercel's production domain, read at build time — the fallback when a deploy
 * doesn't set `NEXT_PUBLIC_SITE_URL` (none did: the live canonical said
 * localhost). Server-only: every consumer of `siteConfig` renders on the server.
 */
const vercelProduction = getServerEnv().VERCEL_PROJECT_PRODUCTION_URL;

export const siteConfig = {
  name: "Ascend",
  /** The home page's <title>: the brand + what it is (≤ 60 chars), from the features heading. */
  title: "Ascend — One platform for your entire revenue engine",
  /** The hero's own sub-line — what the product does, in the page's words. */
  description:
    "Drive your funnel forward with clever workflows, analytics, and seamless lead management — all in one immersive command center.",
  /**
   * Public origin, no trailing slash. Drives canonical URLs, OG tags, the
   * sitemap, and JSON-LD. Set `NEXT_PUBLIC_SITE_URL` in production.
   */
  url:
    publicEnv.NEXT_PUBLIC_SITE_URL ??
    (vercelProduction ? `https://${vercelProduction}` : "http://localhost:3000"),
  /** Default Open Graph / Twitter share image (path under `public/`). */
  ogImage: "/open-graph.jpg",
  /** Alt text for the share image (a 1200×630 capture of the hero). */
  ogImageAlt: "Ascend — “Scale Smarter, Not Harder” above a glowing planet",
  /**
   * Unset until the brand holds a real handle — the starter's `@newproject`
   * would tag whoever owns it. The generator omits the Twitter site/creator
   * tags while this is empty.
   */
  twitterHandle: undefined as string | undefined,
  author: "Ascend",
  /** From the page's copy (hero, features). */
  keywords: [
    "revenue growth",
    "sales automation",
    "workflow automation",
    "funnel analytics",
    "lead management",
    "revenue operations",
  ],
  /** Browser theme-color (address bar / PWA). */
  themeColor: "#04060f",
} as const;
