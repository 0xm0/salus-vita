// 📖 Docs: obsidian/frontend/content.md

/**
 * Ascend's page copy — the shipped site's constants (ascend-old/src/App.jsx),
 * verbatim. Content lives here, never in the view (hard rule #4).
 */

export type IconName = "workflow" | "analytics" | "leads" | "shield" | "bolt" | "globe" | "arrow";

export interface Feature {
  icon: IconName;
  title: string;
  body: string;
}

export interface Stat {
  value: string;
  label: string;
}

export const ascendContent = {
  brand: "Ascend",
  nav: ["Features", "Solutions", "Plans", "Learning"],
  navCta: "Sign Up",
  hero: {
    titleLead: "Scale Smarter,",
    titleTail: "Not",
    titleAccent: "Harder",
    sub: "Drive your funnel forward with clever workflows, analytics, and seamless lead management — all in one immersive command center.",
    primary: "Start Free Right Now",
    secondary: "Schedule a Consult",
  },
  logos: {
    label: "Trusted by fast-moving teams",
    items: ["Nimbus", "Pluma", "Citrus", "Spider", "Helod", "Vertx"],
  },
  features: {
    eyebrow: "Everything in orbit",
    heading: "One platform to run the entire revenue engine",
    lead: "Stop stitching tools together. Ascend unifies capture, automation, and insight into a single surface your whole team actually enjoys using.",
    items: [
      { icon: "workflow", title: "Clever workflows", body: "Automate every hand-off with visual, branching pipelines that move deals forward while you sleep." },
      { icon: "analytics", title: "Live analytics", body: "Real-time dashboards turn raw funnel data into the one number that tells you what to do next." },
      { icon: "leads", title: "Seamless leads", body: "Capture, score, and route every lead automatically — no spreadsheet, no leak, no lag." },
      { icon: "bolt", title: "Instant triggers", body: "Fire actions across your stack the moment intent appears, in milliseconds not minutes." },
      { icon: "shield", title: "Enterprise-grade", body: "SOC 2, SSO, and granular roles baked in — security that scales quietly with your team." },
      { icon: "globe", title: "Global by default", body: "Multi-region, multi-currency, and low-latency everywhere your customers happen to be." },
    ] satisfies Feature[],
  },
  showcase: {
    eyebrow: "Built for momentum",
    heading: "See the whole funnel move in real time",
    lead: "Every stage, every signal, every dollar — rendered live. Ascend gives operators the altitude to spot what's working and the controls to double down instantly.",
    cta: "Explore the platform",
    dashTitle: "Pipeline · Q3",
    dashLive: "Live",
    bars: [62, 88, 47, 95, 71, 80, 58],
    rows: [
      { label: "New leads", fill: 90 },
      { label: "Qualified", fill: 72 },
      { label: "In negotiation", fill: 48 },
      { label: "Closed won", fill: 34 },
    ],
  },
  stats: [
    { value: "3.4×", label: "Faster pipeline velocity" },
    { value: "92%", label: "Lead capture accuracy" },
    { value: "11k+", label: "Teams scaling on Ascend" },
    { value: "$2.1B", label: "Revenue influenced" },
  ] satisfies Stat[],
  cta: {
    eyebrow: "Ready when you are",
    heading: "Put your growth on a new trajectory",
    lead: "Launch in minutes. No credit card. Cancel anytime. Join thousands of teams compounding revenue on Ascend.",
    primary: "Start Free Right Now",
    secondary: "Talk to Sales",
  },
  footer: {
    tagline: "The revenue command center for ambitious teams.",
    cols: [
      { title: "Product", links: [{ label: "Features", href: "#features" }, { label: "Solutions", href: "#solutions" }, { label: "Plans", href: "#cta" }] },
      { title: "Company", links: [{ label: "About", href: "#top" }, { label: "Careers", href: "#top" }, { label: "Blog", href: "#top" }] },
      { title: "Legal", links: [{ label: "Privacy", href: "#top" }, { label: "Terms", href: "#top" }, { label: "Security", href: "#top" }] },
    ],
    copyright: "Ascend, Inc. — Built among the stars.",
  },
} as const;

export type AscendContent = typeof ascendContent;
