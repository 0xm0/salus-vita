"use client";

// 📖 Docs: obsidian/frontend/scene-3d.md

import { useEffect, useRef } from "react";

import { useRobot } from "@/components/common/robot-view";

/** The planet at rest, captured from the running scene — the robot form's backdrop. */
const PLANET_STILL = { desktop: "/assets/robot/planet-desktop.webp", mobile: "/assets/robot/planet-mobile.webp" };

/**
 * The fixed full-viewport WebGL planet behind the page (was Planet.jsx).
 * `pointer-events: none` — it never intercepts scroll or clicks. The scene
 * module (three + its passes) is imported after mount, so it is its own chunk
 * and never part of the first load.
 */
export const PlanetCanvas = () => {
  // The robot form (D-016): a still, no WebGL.
  if (useRobot()) {
    return (
      <picture>
        <source media="(min-width: 640px)" srcSet={PLANET_STILL.desktop} />
        <img src={PLANET_STILL.mobile} alt="" fetchPriority="high" className="pointer-events-none fixed inset-0 z-0 block h-screen w-screen object-cover" />
      </picture>
    );
  }
  return <LivePlanetCanvas />;
};

const LivePlanetCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cleanup: (() => void) | undefined;
    let cancelled = false;
    const start = () => {
      if (cancelled) return;
      void import("@/lib/scene/planet").then(({ initPlanet }) => {
        // The setup in a task of its own, not in the one that evaluated
        // three.js — two shorter tasks on a phone instead of one long one.
        setTimeout(() => {
          if (!cancelled) cleanup = initPlanet(canvas);
        }, 0);
      });
    };
    const stopWaiting = afterHeadlinePaint(start);
    return () => {
      cancelled = true;
      stopWaiting();
      cleanup?.();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0 block h-screen w-screen"
    />
  );
};

/** How long the scene waits for the headline before it starts anyway. */
const HEADLINE_WAIT_MS = 1500;

/**
 * Run `start` once the hero headline has painted (its reveal's first visible
 * frame — a `largest-contentful-paint` entry on the `<h1>`), or after
 * `HEADLINE_WAIT_MS` — whichever comes first.
 *
 * The scene used to start at hydration: three.js (≈140 KB), the Draco decoder,
 * the cloud map and the night-lights model were all fetched and parsed before
 * the headline's first frame, so on a phone the headline — the page's LCP —
 * waited behind them. The planet arrives a beat later instead; it rises in on
 * its own entrance either way.
 */
const afterHeadlinePaint = (start: () => void): (() => void) => {
  let done = false;
  const go = () => {
    if (done) return;
    done = true;
    clearTimeout(timer);
    observer?.disconnect();
    start();
  };
  const timer = setTimeout(go, HEADLINE_WAIT_MS);
  let observer: PerformanceObserver | undefined;
  if ((PerformanceObserver.supportedEntryTypes ?? []).includes("largest-contentful-paint")) {
    observer = new PerformanceObserver((list) => {
      const painted = list
        .getEntries()
        .some((entry) => (entry as PerformanceEntry & { element?: Element | null }).element?.closest("h1"));
      if (painted) go();
    });
    observer.observe({ type: "largest-contentful-paint", buffered: true });
  }
  return () => {
    done = true;
    clearTimeout(timer);
    observer?.disconnect();
  };
};
