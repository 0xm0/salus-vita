"use client";

// 📖 Docs: obsidian/frontend/components/animation-springs.md

import { easings } from "@react-spring/web";
import { useEffect, useState } from "react";

import { Spring } from "@/components/common/robot-spring";
import { useDynamicInView } from "@/hooks/animation/use-dynamic-in-view";
import type { Tags } from "@/types/springs";

/**
 * The shipped site's staggered scroll reveal — `[data-reveal]` + `.in`, a
 * 0.7 s `cubic-bezier(.22,.7,.2,1)` rise of 26 px — as a spring (hard rule #1).
 * `delay` is the old `--rd` stagger. It fires on the same observer the old
 * page used (threshold 0.18, bottom margin −8 %), so what sits at the fold —
 * the logo row — waits for the first scroll, as it did; and it plays once.
 */
const OBSERVER = { threshold: 0.18, rootMargin: "0px 0px -8% 0px" };
const REVEAL_MS = 700;

export const Reveal = ({
  children,
  delay = 0,
  tag = "div",
  className,
}: {
  children: React.ReactNode;
  delay?: number;
  tag?: Tags;
  className?: string;
}) => {
  const [ref, inView] = useDynamicInView(OBSERVER);
  // Latched: the engine's Spring checks `enabled` before `once`, so a reveal
  // tied to `inView` hid again off-screen and replayed on the way back — the
  // shipped page played it once.
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    if (inView) setSeen(true);
  }, [inView]);
  // Promoted to its own layer from load until it has settled: the browser
  // rasters each block once, up front, instead of in the first frame of its
  // reveal mid-scroll (the cold scroll's dropped frames — with the reveals at
  // rest the cold pass dropped none). Released at rest.
  const [settled, setSettled] = useState(false);
  useEffect(() => {
    if (!seen) return;
    const done = setTimeout(() => setSettled(true), delay + REVEAL_MS + 50);
    return () => clearTimeout(done);
  }, [seen, delay]);
  return (
    <Spring
      ref={ref}
      tag={tag}
      mode="once"
      enabled={seen}
      from={{ opacity: 0, y: 26 }}
      to={{ opacity: 1, y: 0 }}
      config={{ duration: REVEAL_MS, easing: easings.easeOutCubic }}
      delayIn={delay}
      className={`${settled ? "" : "will-change-[opacity,transform]"} ${className ?? ""}`}
    >
      {children}
    </Spring>
  );
};
